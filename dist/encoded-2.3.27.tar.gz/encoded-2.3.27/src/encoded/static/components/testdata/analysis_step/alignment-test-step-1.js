module.exports = {
    "@id": "/analysis-steps/1b7bec83-dd21-4086-8673-2e08cf8f1c0f/",
    "@type": ["AnalysisStep", "Item"],
    "name": "alignment-test-step-1",
    "title": "Alignment test step 1",
    "analysis_step_types": ["alignment"],
    "analysis_step_types": ["alignment"],
    "status": "released",
    "uuid": "ab7ec880-50ab-11e4-916c-0800200c9a66"
};
