module.exports = {
    "@id": "/sources/atcc/",
    "@type": ["Source", "Item"],
    "aliases": [],
    "description": "American Type Culture Collection (ATCC)",
    "name": "atcc",
    "status": "current",
    "title": "ATCC",
    "url": "http://www.atcc.org/",
    "uuid": "eadabaf1-d5b6-4b48-8847-e86461f12101"
};