module.exports = {
    "status": "awaiting lab characterization",
    "biosample_term_id": "EFO:0002791",
    "biosample_term_name": "HeLa-S3",
    "organisms": [],
    "targets":[]
};
