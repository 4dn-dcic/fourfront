module.exports = {
    "@id": "/awards/RC2HG005602/",
    "@type": ["Award", "Item"],
    "name": "RC2HG005602",
    "project": "ENCODE",
    "rfa": "ENCODE3"
};
