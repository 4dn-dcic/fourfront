module.exports = {
    "url": "http://funseq2.gersteinlab.org/static/data/ENCODE.annotation.gz",
    "supplementary_data_type": "enhancer annotations",
    "data_summary": "An update of the list in 2014 using the same methodology.",
    "file_format": "BED"
};
