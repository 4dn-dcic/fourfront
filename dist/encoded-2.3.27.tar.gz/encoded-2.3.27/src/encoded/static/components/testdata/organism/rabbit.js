module.exports = {
    "@id": "/organisms/rabbit/",
    "@type": ["Organism", "Item"],
    "status": "current",
    "name": "rabbit",
    "scientific_name": "Oryctolagus cuniculus",
    "schema_version": "2",
    "taxon_id": "9986",
    "uuid": "4f98fd6a-0e61-4988-9032-a5116f6d0607"
};
