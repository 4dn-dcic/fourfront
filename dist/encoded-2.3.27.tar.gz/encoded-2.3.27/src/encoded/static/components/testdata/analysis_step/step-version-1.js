module.exports = {
    "@id": "/analysis-step-versions/871a52b2-6874-4927-98c6-1d0b74bbc194/",
    "@type": ["AnalysisStepVersion", "Item"],
    "status": "released",
    "aliases": [],
    "schema_version": "1",
    "version": 1,
    "analysis_step": require('../analysis_step/encode-2-step'),
    "software_versions": [],
    "uuid": "871a52b2-6874-4927-98c6-1d0b74bbc194"
};
