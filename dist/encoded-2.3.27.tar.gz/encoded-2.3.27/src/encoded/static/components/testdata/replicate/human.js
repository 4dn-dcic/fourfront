module.exports = {
    "@id": "/replicates/30a3e114-139a-4297-9287-4f23d2754c25/",
    "@type": ["Replicate", "Item"],
    "aliases": [],
    "biological_replicate_number": 1,
    "experiment": "/experiments/ENCSR999NOF/",
    "library": require('../library/sid38806'),
    "paired_ended": false,
    "submitted_by": "/users/0abbd494-b852-433c-b360-93996f679dae/",
    "technical_replicate_number": 1,
    "uuid": "30a3e114-139a-4297-9287-4f23d2754c25"
};