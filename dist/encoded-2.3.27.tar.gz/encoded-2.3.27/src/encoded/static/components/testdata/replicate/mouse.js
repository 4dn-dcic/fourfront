module.exports = {
    "@id": "/replicates/401d9e79-8a0a-42ed-ad1b-1d274fd0b8cb/",
    "@type": ["Replicate", "Item"],
    "aliases": [],
    "biological_replicate_number": 2,
    "experiment": "/experiments/ENCSR999NOF/",
    "library": require('../library/sid38807'),
    "paired_ended": false,
    "submitted_by": "/users/0abbd494-b852-433c-b360-93996f679dae/",
    "technical_replicate_number": 1,
    "uuid": "401d9e79-8a0a-42ed-ad1b-1d274fd0b8cb"
};