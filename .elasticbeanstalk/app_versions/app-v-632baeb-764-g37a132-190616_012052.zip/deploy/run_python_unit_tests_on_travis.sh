#!/bin/bash
bin/test -v -v -m "working and not setone" --durations=10 --cov src/encoded
