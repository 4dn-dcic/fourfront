module.exports = {
    "@id": "/organisms/human/",
    "@type": ["Organism", "Item"],
    "name": "human",
    "scientific_name": "Homo sapiens",
    "taxon_id": "9606",
    "uuid": "7745b647-ff15-4ff3-9ced-b897d4e2983c"
};