module.exports = {
    "@id": "/analysis-step-runs/cbc4fbba-5ce6-49ef-b7a4-46ece2147b67/",
    "@type": ["AnalysisStepVersion", "Item"],
    "aliases": [],
    "schema_version": "2",
    "analysis_step_version": require('./step-version-1'),
    "workflow_run": {},
    "status": "finished",
    "uuid": "cbc4fbba-5ce6-49ef-b7a4-46ece2147b67"
};
