module.exports = {
    "@id": "/sources/aviva/",
    "@type": [  
        "Source",
        "Item"
    ],
    "status": "current",
    "uuid": "fa701215-07e6-4ffe-a8f4-20356d66f3e0",
    "title": "Aviva",
    "url": "http://www.avivasysbio.com",
    "description": "Aviva Systems Biology",
    "schema_version": "2",
    "name": "aviva",
};
