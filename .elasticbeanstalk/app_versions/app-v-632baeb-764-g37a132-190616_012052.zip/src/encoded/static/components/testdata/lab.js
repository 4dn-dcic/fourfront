module.exports = {
    "@id": "/labs/thomas-gingeras/",
    "@type": ["lab", "item"],
    "title": "Thomas Gingeras, CSHL"
};