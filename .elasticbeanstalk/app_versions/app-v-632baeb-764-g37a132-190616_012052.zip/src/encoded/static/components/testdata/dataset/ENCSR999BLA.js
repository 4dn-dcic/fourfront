module.exports = {
    "@id": "/datasets/ENCSR999BLA/",
    "@type": ["Dataset", "Item"],
    "accession": "ENCSR999BLA",
    "award": "U54HG004576",
    "dataset_type": "composite",
    "description": "Testing dataset",
    "lab": "richard-myers",
    "status": "released",
    "submitted_by": "facilisi.tristique@potenti.vivamus",
    "uuid": "d2470afe-ac68-4489-8f51-90ddfbc8e00b"
};
