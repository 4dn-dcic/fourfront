module.exports = {
    "@id": "/organisms/mouse/",
    "@type": ["Organism", "Item"],
    "name": "mouse",
    "scientific_name": "Mus musculus",
    "taxon_id": "10090",
    "uuid": "3413218c-3d86-498b-a0a2-9a406638e786"
};