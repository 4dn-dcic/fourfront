'use strict';

import React from 'react';
import _ from 'underscore';
import url from 'url';
import memoize from 'memoize-one';
import { Button, DropdownButton, MenuItem } from 'react-bootstrap';
import * as vizUtil from './../utilities';
import { Legend } from './../components';
import { console, Filters, Schemas, layout, analytics } from './../../util';
import { Toggle } from './../../forms/components';
import { boundActions } from './ViewContainer';

/**
 * Component which wraps BarPlot.Chart and provides some UI buttons and stuff.
 * Passes props to BarPlot.Chart.
 */
export class UIControlsWrapper extends React.PureComponent {

    static canShowChart(chartData){
        if (!chartData) return false;
        if (!chartData.total) return false;
        if (chartData.total && chartData.total.experiment_sets === 0) return false;
        if (typeof chartData.field !== 'string') return false;
        if (typeof chartData.terms !== 'object') return false;
        if (_.keys(chartData.terms).length === 0) return false;
        return true;
    }

    static defaultProps = {
        'titleMap' : {
            // Aggr type
            'experiment_sets'   : "Experiment Sets",
            'experiments'       : 'Experiments',
            'files'             : "Files",

            // Show state
            'all'               : 'All',
            'filtered'          : 'Selected',
            'both'              : 'All & Selected'
        },
        'availableFields_XAxis' : [
            { title : "Experiment Type", field : 'experiments_in_set.experiment_type.display_title' },
            //{ title : "Digestion Enzyme", field : "experiments_in_set.digestion_enzyme.name" },
            { title : "Biosource", field : "experiments_in_set.biosample.biosource_summary" },
            { title : "Biosource Type", field : 'experiments_in_set.biosample.biosource.biosource_type' },
            { title : "Organism", field : "experiments_in_set.biosample.biosource.individual.organism.name" },
            { title : "Project", field : "award.project" },
            { title : "Lab", field : "lab.display_title" },
            { title : "Status", field : "status" }
        ],
        'availableFields_Subdivision' : [
            { title : "Organism", field : "experiments_in_set.biosample.biosource.individual.organism.name" },
            { title : "Experiment Type", field : 'experiments_in_set.experiment_type.display_title' },
            //{ title : "Digestion Enzyme", field : "experiments_in_set.digestion_enzyme.name" },
            { title : "Biosource Type", field : 'experiments_in_set.biosample.biosource.biosource_type' },
            { title : "Biosource", field : "experiments_in_set.biosample.biosource_summary" },
            { title : "Project", field : "award.project" },
            { title : "Center", field : "award.center_title" },
            { title : "Lab", field : "lab.display_title" },
            { title : "Status", field : "status" }
        ],
        'legend' : false,
        'chartHeight' : 300
    }

    constructor(props){
        super(props);
        this.filterObjExistsAndNoFiltersSelected = this.filterObjExistsAndNoFiltersSelected.bind(this);
        this.titleMap = this.titleMap.bind(this);
        this.adjustedChildChart = this.adjustedChildChart.bind(this);
        this.handleAggregateTypeSelect = _.throttle(this.handleAggregateTypeSelect.bind(this), 750);
        this.handleExperimentsShowType = _.throttle(this.handleExperimentsShowType.bind(this), 750, { trailing : false });
        this.handleFieldSelect = _.throttle(this.handleFieldSelect.bind(this), 300);
        this.getFieldAtIndex = this.getFieldAtIndex.bind(this);
        this.contextualView = this.contextualView.bind(this);
        this.renderDropDownMenuItems = this.renderDropDownMenuItems.bind(this);
        this.handleDropDownToggle = this.handleDropDownToggle.bind(this);
        this.renderShowTypeDropdown = this.renderShowTypeDropdown.bind(this);

        this.state = {
            'aggregateType' : 'experiment_sets',
            'showState' : this.filterObjExistsAndNoFiltersSelected(props.expSetFilters) || (props.barplot_data_filtered && props.barplot_data_filtered.total.experiment_sets === 0) ? 'all' : 'filtered',
            'openDropdown' : null
        };
    }

    UNSAFE_componentWillReceiveProps(nextProps){
        // TODO: Refactor into getDerivedStateFromProps
        if (
            // TODO: MAYBE REMOVE HREF WHEN SWITCH SEARCH FROM /BROWSE/
            (
                !this.props.barplot_data_filtered || (this.props.barplot_data_filtered && this.props.barplot_data_filtered.total.experiment_sets === 0)
            ) && (
                (nextProps.barplot_data_filtered && nextProps.barplot_data_filtered.total.experiment_sets > 0)
            ) && (
                this.state.showState === 'all'
            )
        ){
            this.setState({ 'showState' : 'filtered' });
        } else if (
            // TODO: MAYBE REMOVE HREF WHEN SWITCH SEARCH FROM /BROWSE/
            (
                !nextProps.barplot_data_filtered || (nextProps.barplot_data_filtered && nextProps.barplot_data_filtered.total.experiment_sets === 0)
            ) && (
                (this.props.barplot_data_filtered && this.props.barplot_data_filtered.total.experiment_sets > 0)
            ) && (
                this.state.showState === 'filtered'
            )
        ){
            this.setState({ 'showState' : 'all' });
        }
    }

    // TODO: MAYBE REMOVE HREF WHEN SWITCH SEARCH FROM /BROWSE/
    filterObjExistsAndNoFiltersSelected(expSetFilters = this.props.expSetFilters, href = this.props.href){
        return Filters.filterObjExistsAndNoFiltersSelected(expSetFilters) && !Filters.searchQueryStringFromHref(href);
    }

    titleMap(key = null, fromDropdown = false){
        if (!key) return this.props.titleMap;
        var title = this.props.titleMap[key];
        if (fromDropdown && ['all','filtered'].indexOf(key) > -1){
            title += ' ' + this.titleMap(this.state.aggregateType);
        } else if (fromDropdown && key == 'both'){
            return 'Both';
        }
        return title;
    }

    /**
     * Clones props.children, expecting a Chart React Component as the sole child, and extends Chart props with 'fields', 'showType', and 'aggregateType'.
     *
     * @returns {React.Component} Cloned & extended props.children.
     */
    adjustedChildChart(){
        // TODO: validate that props.children is a BarPlot.Chart

        return React.cloneElement(
            this.props.children,
            _.extend(
                _.omit( // Own props minus these.
                    this.props,
                    'titleMap', 'availableFields_XAxis', 'availableFields_Subdivision', 'legend', 'chartHeight', 'children'
                ),
                {
                    'fields' : this.props.barplot_data_fields,
                    'showType' : this.state.showState,
                    'aggregateType' : this.state.aggregateType
                }
            )
        );
    }


    handleAggregateTypeSelect(eventKey, event){
        this.setState({ aggregateType : eventKey });
    }

    handleExperimentsShowType(eventKey, event){
        this.setState({ showState : eventKey });
    }

    /**
     * Handler for the Dropdown components which offer field options.
     *
     * @param {number} fieldIndex   Index of field in aggregation being changed -- must be 0 or 1.
     * @param {string} newFieldKey  Dot-delimited name of field used for aggregation, e.g. 'lab.display_title'.
     * @param {Event} [event]       Reference to event of DropDown change.
     */
    handleFieldSelect(fieldIndex, newFieldKey, event = null){
        var newFields;
        if (newFieldKey === "none"){ // Only applies to subdivision (fieldIndex 1)
            newFields = this.props.barplot_data_fields.slice(0,1);
            this.props.updateBarPlotFields(newFields);
            return;
        }

        var newField = _.find(
            this.props['availableFields' + (fieldIndex === 0 ? '_XAxis' : '_Subdivision') ],
            { field : newFieldKey }
        );
        var otherFieldIndex = fieldIndex === 0 ? 1 : 0;
        if (fieldIndex === 0 && this.props.barplot_data_fields.length === 1){
            newFields = [null];
        } else {
            newFields = [null, null];
        }
        newFields[fieldIndex] = newField;
        if (newFields.length > 1){
            var foundFieldFromProps = _.findWhere(this.props.availableFields_Subdivision.slice(0).concat(this.props.availableFields_XAxis.slice(0)), { 'field' : this.props.barplot_data_fields[otherFieldIndex] });
            newFields[otherFieldIndex] = foundFieldFromProps || {
                'title' : this.props.barplot_data_fields[otherFieldIndex],
                'field' : this.props.barplot_data_fields[otherFieldIndex]
            };
        }
        setTimeout(()=>{
            this.props.updateBarPlotFields(_.pluck(newFields, 'field'));
            analytics.event('BarPlot', 'Set Aggregation Field', {
                'eventLabel' : '[' + _.pluck(newFields, 'field').join(', ') + ']',
                'field' : newFieldKey
            });
        }, 0);
    }

    getFieldAtIndex(fieldIndex){
        if (!this.props.barplot_data_fields) return null;
        if (!Array.isArray(this.props.barplot_data_fields)) return null;
        if (this.props.barplot_data_fields.length < fieldIndex + 1) return null;

        return (
            _.findWhere(this.props.availableFields_Subdivision.slice(0).concat(this.props.availableFields_XAxis.slice(0)), { 'field' : this.props.barplot_data_fields[fieldIndex] })
        ) || {
            'title' : this.props.barplot_data_fields[fieldIndex],
            'field' : this.props.barplot_data_fields[fieldIndex]
        };
    }

    contextualView(){
        if (this.props.href){
            // Hide on homepage.
            var hrefParts = url.parse(this.props.href);
            if (hrefParts.pathname === '/' || hrefParts.pathname === '/home'){
                return 'home';
            }
        }
        return 'browse';
    }

    renderDropDownMenuItems(keys, active = null){
        return keys.map((key)=>{
            var subtitle = null;
            var title = null;
            var disabled = null;
            var tooltip = null;
            if (Array.isArray(key)){
                // Assume we have [key, title, subtitle].
                title = key[1] || null;
                subtitle = key[2] || null;
                disabled = key[3] || false;
                tooltip = key[4] || null;
                key = key[0];
            }

            if (typeof title === 'string' && typeof tooltip === 'string'){
                title = <span className="inline-block" data-tip={tooltip} data-place="left">{ title }</span>;
            }

            return <MenuItem
                key={key}
                eventKey={key}
                active={key === active}
                children={title || this.titleMap(key, true)}
                disabled={disabled}
            />;
        });
    }

    handleDropDownToggle(id, isOpen, evt, source){
        if (isOpen){
            setTimeout(this.setState.bind(this), 10, { 'openDropdown' : id });
        } else {
            this.setState({ 'openDropdown' : null });
        }
    }

    renderShowTypeDropdown(contextualView){
        if (contextualView === 'home') return null;
        // TODO: MAYBE REMOVE HREF WHEN SWITCH SEARCH FROM /BROWSE/
        var isSelectedDisabled = (this.filterObjExistsAndNoFiltersSelected() && !Filters.searchQueryStringFromHref(this.props.href)) || (this.props.barplot_data_filtered && this.props.barplot_data_filtered.total.experiment_sets === 0);
        return (
            <div className="show-type-change-section">
                <h6 className="dropdown-heading">
                    <span className="inline-block" data-tip={isSelectedDisabled ? "Enable some filters to enable toggling between viewing all and selected items." : null}>Show</span>
                </h6>
                <DropdownButton
                    id="select-barplot-show-type"
                    onSelect={this.handleExperimentsShowType}
                    bsSize='xsmall'
                    disabled={isSelectedDisabled}
                    title={(()=>{
                        //if (this.state.openDropdown === 'subdivisionField'){
                        //    return <em className="dropdown-open-title">Color Bars by</em>;
                        //}
                        var aggrType = this.titleMap(this.state.aggregateType);
                        var showString = this.state.showState === 'all' ? 'All' : 'Selected';
                        return (
                            <span>
                                <span className="text-600">{ showString }</span> { aggrType }
                            </span>
                        );
                    })()}
                    onToggle={this.handleDropDownToggle.bind(this, 'showType')}
                    children={this.renderDropDownMenuItems([
                        ['all', <span>
                            <span className="text-500">All</span> { this.titleMap(this.state.aggregateType) }
                        </span>],
                        ['filtered', <span className="inline-block" data-place="left" data-tip={isSelectedDisabled ? 'No filters currently set' : null}>
                            <span className="text-500">Selected</span> { this.titleMap(this.state.aggregateType) }
                        </span>, null, isSelectedDisabled]
                    ], this.state.showState)}
                />
            </div>
        );
    }

    renderGroupByFieldDropdown(contextualView){
        return (
            <div className="field-1-change-section">
                <h6 className="dropdown-heading">Group By</h6>
                <DropdownButton
                    id="select-barplot-field-1"
                    onSelect={this.handleFieldSelect.bind(this, 1)}
                    disabled={this.props.isLoadingChartData}
                    title={(()=>{
                        //if (this.state.openDropdown === 'subdivisionField'){
                        //    return <em className="dropdown-open-title">Color Bars by</em>;
                        //}
                        if (this.props.isLoadingChartData){
                            return <span style={{ opacity : 0.33 }}><i className="icon icon-spin icon-circle-o-notch"/></span>;
                        }
                        var field = this.getFieldAtIndex(1);
                        if (!field) return "None";
                        return field.title || Schemas.Field.toName(field.field);
                    })()}
                    onToggle={this.handleDropDownToggle.bind(this, 'subdivisionField')}
                    children={this.renderDropDownMenuItems(
                        this.props.availableFields_Subdivision.slice(0).concat([{
                            title : <em>None</em>,
                            field : "none"
                        }]).map((field)=>{
                            var isDisabled = this.props.barplot_data_fields[0] === field.field;
                            return [
                                field.field,                                        // Field
                                field.title || Schemas.Field.toName(field.field),   // Title
                                field.description || null,                          // Description
                                //isDisabled,                                         // Disabled
                                //isDisabled ? "Field already selected for X-Axis" : null
                            ]; // key, title, subtitle, disabled
                        }),
                        this.props.barplot_data_fields[1] || "none"
                    )}
                />
            </div>
        );
    }

    render(){
        var { barplot_data_filtered, barplot_data_unfiltered, barplot_data_fields, isLoadingChartData,
            availableFields_XAxis, availableFields_Subdivision, schemas, chartHeight, windowWidth, cursorDetailActions } = this.props;
        var { aggregateType, showState } = this.state;

        if (!UIControlsWrapper.canShowChart(barplot_data_unfiltered)) return null;

        var windowGridSize = layout.responsiveGridState(windowWidth);
        var contextualView = this.contextualView();

        var legendContainerHeight = windowGridSize === 'xs' ? null :
            this.props.chartHeight - (49 * (contextualView === 'home' ? 1 : 2 )) - 50;

        vizUtil.unhighlightTerms();

        return (
            <div className="bar-plot-chart-controls-wrapper">
                <div className="overlay" style={{
                    width  : (windowGridSize !== 'xs' ? (layout.gridContainerWidth(windowWidth) * (9/12) - 15) : null)
                }}>

                    <div className="y-axis-top-label" style={{
                        width : chartHeight,
                        top: chartHeight - 4
                    }}>
                        <div className="row" style={{ 'maxWidth' : 210, 'float': 'right' }}>
                            <div className="col-xs-3" style={{ 'width' : 51 }}>
                                <h6 className="dropdown-heading">Y Axis</h6>
                            </div>
                            <div className="col-xs-9" style={{ 'width' : 159, 'textAlign' : 'left' }}>
                                <DropdownButton
                                    id="select-barplot-aggregate-type"
                                    bsSize="xsmall"
                                    onSelect={this.handleAggregateTypeSelect}
                                    title={this.titleMap(aggregateType)}
                                    onToggle={this.handleDropDownToggle.bind(this, 'yAxis')}
                                    children={this.renderDropDownMenuItems(['experiment_sets','experiments','files'], aggregateType)}
                                />
                            </div>
                        </div>
                    </div>

                    {/* this.renderShowTypeToggle(windowGridSize) */}

                </div>

                <div className="row">
                    <div className="col-sm-9" children={this.adjustedChildChart()} />
                    <div className="col-sm-3 chart-aside" style={{ 'height' : chartHeight }}>
                        { this.renderShowTypeDropdown(contextualView) }
                        { this.renderGroupByFieldDropdown(contextualView) }
                        <div className="legend-container" style={{ 'height' : legendContainerHeight }}>
                            <AggregatedLegend {...{ cursorDetailActions, barplot_data_filtered, barplot_data_unfiltered, aggregateType, schemas }}
                                height={legendContainerHeight}
                                field={_.findWhere(availableFields_Subdivision, { 'field' : barplot_data_fields[1] }) || null}
                                showType={showState} />
                        </div>
                        <div className="x-axis-right-label">
                            <div className="row">
                                <div className="col-xs-3" style={{ width : 51 }}>
                                    <h6 className="dropdown-heading">X Axis</h6>
                                </div>
                                <div className="col-xs-9 pull-right" style={{ "width" : (layout.gridContainerWidth(windowWidth) * (windowGridSize !== 'xs' ? 0.25 : 1)) + 5 - 52 }}>
                                    <DropdownButton
                                        id="select-barplot-field-0"
                                        onSelect={this.handleFieldSelect.bind(this, 0)}
                                        disabled={isLoadingChartData}
                                        title={(()=>{
                                            //if (this.state.openDropdown === 'xAxisField'){
                                            //    return <em className="dropdown-open-title">X-Axis Field</em>;
                                            //}
                                            if (isLoadingChartData){
                                                return <span style={{ opacity : 0.33 }}><i className="icon icon-spin icon-circle-o-notch"/></span>;
                                            }
                                            var field = this.getFieldAtIndex(0);
                                            return <span>{(field.title || Schemas.Field.toName(field.field))}</span>;
                                        })()}
                                        onToggle={this.handleDropDownToggle.bind(this, 'xAxisField')}
                                        children={this.renderDropDownMenuItems(
                                            availableFields_XAxis.map((field)=>{
                                                var isDisabled = barplot_data_fields[1] && barplot_data_fields[1] === field.field;
                                                return [
                                                    field.field,
                                                    field.title || Schemas.Field.toName(field.field),
                                                    field.description || null,
                                                    //isDisabled,
                                                    //isDisabled ? 'Field is already selected for "Group By"' : null
                                                ]; // key, title, subtitle
                                            }),
                                            barplot_data_fields[0]
                                        )}
                                    />
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        );
    }

}

export class AggregatedLegend extends React.Component {

    static collectSubDivisionFieldTermCounts = memoize(function(rootField, aggregateType = 'experiment_sets'){
        if (!rootField) return null;

        var retField = {
            'field' : null,
            'terms' : {},
            'total' : {
                'experiment_sets' : 0,
                'experiments' : 0,
                'files' : 0
            }
        };

        _.forEach(_.keys(rootField.terms), function(term){
            var childField = rootField.terms[term];
            if (typeof retField.field === 'undefined' || !retField.field) retField.field = childField.field;

            _.forEach(_.keys(childField.terms), function(t){
                if (typeof retField.terms[t] === 'undefined'){
                    retField.terms[t] = {
                        'experiment_sets' : 0,
                        'experiments' : 0,
                        'files' : 0
                    };
                }
                retField.terms[t].experiment_sets += childField.terms[t].experiment_sets;
                retField.terms[t].experiments += childField.terms[t].experiments;
                retField.terms[t].files += childField.terms[t].files;
                retField.total.experiment_sets += childField.terms[t].experiment_sets;
                retField.total.experiments += childField.terms[t].experiments;
                retField.total.files += childField.terms[t].files;
            });
        });

        retField.terms = _.object(_.sortBy(_.pairs(retField.terms), function(termPair){ return termPair[1][aggregateType]; }));

        return retField;
    });

    constructor(props){
        super(props);
        this.getFieldForLegend = this.getFieldForLegend.bind(this);
        this.updateIfShould = this.updateIfShould.bind(this);
        this.width = this.width.bind(this);
        this.height = this.height.bind(this);

        this.legendContainerRef = React.createRef();
    }

    componentDidMount(){
        this.updateIfShould();
    }

    componentDidUpdate(pastProps, pastState){
        this.updateIfShould();
    }

    getFieldForLegend(){
        var { field, barplot_data_unfiltered, barplot_data_filtered, aggregateType, showType } = this.props;
        return Legend.barPlotFieldDataToLegendFieldsData(
            AggregatedLegend.collectSubDivisionFieldTermCounts(
                showType === 'all' ? barplot_data_unfiltered : barplot_data_filtered || barplot_data_unfiltered,
                aggregateType || 'experiment_sets',
                field
            ),
            function(term){ return typeof term[aggregateType] === 'number' ? -term[aggregateType] : 'term'; }
        );
    }

    /**
     * Do a forceUpdate() in case we set this.shouldUpdate = true in an initial render.
     * this.shouldUpdate would be set if legend fields do not have colors yet from cache.
     */
    updateIfShould(){
        var fieldForLegend = this.getFieldForLegend(),
            shouldUpdate = (
                fieldForLegend &&
                fieldForLegend.terms && fieldForLegend.terms.length > 0 &&
                fieldForLegend.terms[0] && fieldForLegend.terms[0].color === null
            );

        if (shouldUpdate){
            setTimeout(()=>{
                this.forceUpdate();
            }, 750);
        }
    }

    width(){
        if (this.props.width) return this.props.width;
        var elem = this.legendContainerRef.current,
            width = elem && elem.offsetWidth;

        return width || layout.gridContainerWidth(this.props.windowWidth) * (3/12) - 15;
    }

    height(){
        if (this.props.height) return this.props.height;
        var elem = this.legendContainerRef.current,
            height = elem && elem.offsetHeight;

        return height || null;
    }

    render(){
        var { field, barplot_data_unfiltered, isLoadingChartData, aggregateType, href, cursorDetailActions } = this.props;
        if (!field || !barplot_data_unfiltered || isLoadingChartData || (barplot_data_unfiltered.total && barplot_data_unfiltered.total.experiment_sets === 0)) return null;

        var fieldForLegend = this.getFieldForLegend();

        return (
            <div className="legend-container-inner" ref={this.legendContainerRef}>
                <Legend {...{ href, aggregateType, cursorDetailActions }} field={this.getFieldForLegend() || null}
                    includeFieldTitles={false} schemas={this.props.schemas}
                    width={this.width()} height={this.height()} hasPopover
                    //expandable
                    //expandableAfter={8}
                    //cursorDetailActions={boundActions(this, showType)}
                />
            </div>
        );
    }
}
